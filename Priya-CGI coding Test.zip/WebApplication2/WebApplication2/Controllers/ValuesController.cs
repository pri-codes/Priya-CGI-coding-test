﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/Values")]
    [ApiController]
    public class ValuesController : Controller
    {
        private readonly APIContext _context;

        public ValuesController(APIContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Fetchbooks()
        {
            List<Book> books = _context.GetBooks();

            return Ok(books);
        }

        public JsonResult SaveBook(Book b)
        {
            bool status = false;
            try
            {
                _context.Add(b);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                status = false;
            }

            return Json(status);
        }

        public JsonResult UpdateBook(Book book1, string newName)
        {
            bool status = false;
            try
            {
                var book = (from b in _context.Books
                            where b.Name == book1.Name
                            select b).FirstOrDefault();

                book.Name = newName;

                _context.SaveChanges();
            }
            catch (Exception)
            {

                status = false;
            }

            return Json(status);
        }


        public JsonResult DeleteBook(Book book1)
        {
            bool status = false;
            try
            {
                var book = (from b in _context.Books
                            where b.Name == book1.Name
                            select b).FirstOrDefault();
                _context.Books.Remove(book);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                status = false;
            }

            return Json(status);

        }

    }
}
