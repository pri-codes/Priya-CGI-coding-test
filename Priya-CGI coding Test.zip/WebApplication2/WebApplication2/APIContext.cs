﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2
{
    public class APIContext : DbContext
    {

        public APIContext(DbContextOptions<APIContext> options)
            : base(options)
        {
            LoadBooks();
        }

        public DbSet<Book> Books { get; set; }

        public void LoadBooks()
        {
            var book1 = new Book
            {
                Name = "XYZ",
                Author = "Luke",
                ReleasedDate = "XYZ",
                Description = "XYZ",
                Rating = 5,
                NumberOfReviews = 1000
            };

            Books.Add(book1);

            var book2 = new Book
            {
                Name = "ABC",
                Author = "Alex",
                ReleasedDate = "ABC",
                Description = "ABC",
                Rating = 3,
                NumberOfReviews = 2000
            };

            Books.Add(book2);


            var book3 = new Book
            {
                Name = "DEF",
                Author = "Sally",
                ReleasedDate = "DEF",
                Description = "DEF",
                Rating = 4,
                NumberOfReviews = 100
            };

            Books.Add(book3);
        }

        public List<Book> GetBooks()
        {
            return Books.Local.ToList<Book>();
        }
    }
}
