using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<APIContext>(opt => opt.UseInMemoryDatabase("BookApp"));
            services.AddScoped<APIContext>();
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "WebApplication2", Version = "v1" });
            });

            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {

            var scope = app.ApplicationServices.CreateScope();
            var context = scope.ServiceProvider.GetService<APIContext>();
            //AddTestData(context);

            app.UseCors("MyPolicy");
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "WebApplication2 v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }


        private static void AddTestData(APIContext context)
        {
            var book1 = new Book
            {
                Name = "XYZ",
                Author = "Luke",
                ReleasedDate = "XYZ",
                Description = "XYZ",
                Rating = 5,
                NumberOfReviews = 1000
            };

            context.Books.Add(book1);

            var book2 = new Book
            {
                Name = "ABC",
                Author = "Alex",
                ReleasedDate = "ABC",
                Description = "ABC",
                Rating = 3,
                NumberOfReviews = 2000
            };

            context.Books.Add(book2);


            var book3 = new Book
            {
                Name = "DEF",
                Author = "Sally",
                ReleasedDate = "DEF",
                Description = "DEF",
                Rating = 4,
                NumberOfReviews = 100
            };

            context.Books.Add(book3);
        }
    }
}
