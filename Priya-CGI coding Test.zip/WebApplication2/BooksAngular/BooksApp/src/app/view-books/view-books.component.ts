import { Component, OnInit } from '@angular/core';
import { BookServiceService } from '../book-service.service';
import { IBook } from '../interfaces/Book';

@Component({
  selector: 'app-view-books',
  templateUrl: './view-books.component.html',
  styleUrls: ['./view-books.component.css']
})
export class ViewBooksComponent implements OnInit {

  books: IBook[];

  constructor(private bookservice: BookServiceService) { }

  ngOnInit(): void {

    this.getBooks();
  }


  getBooks() {
    this.bookservice.getBooks().subscribe(
      responseData => {
        this.books = responseData;
        console.log(this.books);
      }
    );
  }

  addToWishList(name: string) {

    alert(name + " is added to your wishlist!");


  }

}
