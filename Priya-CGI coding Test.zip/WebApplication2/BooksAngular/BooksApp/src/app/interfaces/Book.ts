export interface IBook {

  Name: string,
  Author: string,
  ReleasedDate: string,
  Description: string,
  Rating: number,
  NumberOfReviews: number;




}
