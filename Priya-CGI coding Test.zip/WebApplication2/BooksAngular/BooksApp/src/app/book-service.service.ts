import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IBook } from './interfaces/Book';

@Injectable({
  providedIn: 'root'
})
export class BookServiceService {


  constructor(private http: HttpClient) { }


  getBooks(): Observable<IBook[]> {
    let tempvar = this.http.get<IBook[]>("https://localhost:44395/api/Values");

    return tempvar;
  }
}
